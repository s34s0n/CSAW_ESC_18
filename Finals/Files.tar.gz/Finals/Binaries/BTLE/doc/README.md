See some docs which are useful in [https://github.com/JiaoXianjun/doc](https://github.com/JiaoXianjun/doc)

See new type of discovery packet in host/btle-tools/src/packets_discovery.txt


